<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Model\Attendance;
use App\User;
use Carbon\Carbon;
use Auth;
use DB;

class CheckController extends Controller
{

	public  function checkin(Request $request){

		$user = Auth::user();
		if ($user) {
			$checkin = new Attendance;
			$checkin->idno 		= $user->idno;
			$checkin->employee 	= $user->name;
			$checkin->reference = $user->reference;
			$checkin->status_timein = 'ok';
			$checkin->timein 	= Carbon::now()->toTimeString();
			$checkin->date 		= Carbon::now()->toDateString();
			if ($checkin->save()) {
				return response()->json('success', 200);          
			}else{
				return response()->json('error', 500);
			}
			return response()->json($checkin);
		}
	}

	public function checkout(Request $request)
	{
		$user = Auth::user();
		if ($user) {
			$checkin =  Attendance::where('idno',$user->idno)->where('status_timeout','')->first();
			if ($checkin->status_timeout == '') {
				$checkin->timeout = Carbon::now()->toTimeString();
				$timein = Carbon::createFromFormat('H:i:s', $checkin->timein);
				$timeout = Carbon::createFromFormat('H:i:s',Carbon::now()->toTimeString());
				$th = $timein->diffInHours($timeout);
				$tm = floor(($timein->diffInMinutes($timeout) - (60 * $th)));
				$total = $th.".".$tm;
				$checkin->totalhours = $total;
				$checkin->status_timeout = 'ok';
				$checkin->save();
				return response()->json($checkin); 
			}
		}

	}
}